var get = require("./get.js");
var getPrototypeOf = require("./getPrototypeOf.js");
function _superPropGet(t, o, e, r) {
  var p = get(getPrototypeOf(1 & r ? t.prototype : t), o, e);
  return 2 & r && "function" == typeof p ? function (t) {
    return p.apply(e, t);
  } : p;
}
module.exports = _superPropGet, module.exports.__esModule = true, module.exports["default"] = module.exports;