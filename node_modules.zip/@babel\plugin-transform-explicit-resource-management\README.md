# @babel/plugin-transform-explicit-resource-management

> Compile `using` and `await using` declarations to ES2015

See our website [@babel/plugin-transform-explicit-resource-management](https://babeljs.io/docs/babel-plugin-transform-explicit-resource-management) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-explicit-resource-management
```

or using yarn:

```sh
yarn add @babel/plugin-transform-explicit-resource-management --dev
```
